<!DOCTYPE html>
<html>
    <head>
        <title>Sign up</title>

        <link rel="stylesheet" href="css/bootstrap.min.css"/>
        <link rel="stylesheet" href="css/main.css"/>
        <meta name="viewport" content="width=device-width, initial-scale=1, user-scaleable=no">
        <script src="https://ajax.googleapis.com/ajax/libs/jquery/2.1.3/jquery.min.js"></script>
        <script src="js/bootstrap.min.js"></script>
    </head>

    <body>
        
        <div class="container-fluid">

                <nav class="navbar navbar-inverse mynav">
                        <!--<nav class="navbar navbar-default mynav" data-spy="affix" data-offset-top="100">-->
                        <div class="container">
                            <!-- Brand and toggle get grouped for better mobile display -->
                            <div class="navbar-header">
                                <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#myid" aria-expanded="false">
                        <span class="sr-only">Toggle navigation</span>
                        <span class="icon-bar"></span>
                        <span class="icon-bar"></span>
                        <span class="icon-bar"></span>
                      </button>
                
                             
                               
                
                                <!-- <a class="navbar-brand" href="#">Brand</a>-->
                            </div>
                
                            <!-- Collect the nav links, forms, and other content for toggling -->
                            <div class="collapse navbar-collapse" id="myid">
                                <ul class="nav navbar-nav">
                                    <li><?php echo '<a href="/">Home<span class="sr-only">(current)</span></a>.'; ?></li>
                                    
                
                 
                
                
                                 
                
                
                
                          
                <li> <?php echo '<a href="cv_submission_form.php">CV</a>.'; ?></li>
                     
                
                
                
                
                
                        
                
                                       
                                    
                                 
                                    
                                    
                                    
                                    
                
                
                
                        </ul>
                            
                          
                                <div class="logo hidden-xs">
                
                                    <img src="images/lg.png" alt="" style="width:200; height:70px;">
                                </div>
                
                           
                           
                           
                           
                           <ul class="nav navbar-nav navbar-right">
                                   
                                    <li><?php echo '<a href="contact">Contact Us </a>.'; ?></li>
                                <li> <?php echo '<a href="signin">Sign In</a>.'; ?></li>
                
                                </ul>
                            
                      
                      
                    
                
                        
                        </div>
                        
                        
                        
                         
                        
                     
                
                        <!-- /.navbar-collapse -->
                        </div>
                        <!-- /.container-fluid -->
                    </nav>

            
        <div style = "border:1px solid black;border-radius:5px;padding:10px;width:70%;margin:5% 0 0 15%;background-color: #fafafa">
                <h3 style=" margin-bottom: 40px; margin-left: 42%;">Registretion Form</h3>
            <form class="form-horizontal" action="{{URL::to('/submit')}}" method="POST" style="margin-left: 100px;">
                {{csrf_field()}}
                @if(session('response'))
                    <div class="col-sm-12 alert">
                        {{session('response')}}
                    </div>
                

                @else
                <div class="form-group">
                    <label class="control-label col-sm-2" for="user_name">User Id:</label>
                    <div class="col-sm-7">
                        <input type="text" class="form-control" id="user_id" onblur="checkUserName()" placeholder="Enter user name" name="uid" required>
                        <label class="control-label col-sm-2" for="user_name" id="uv" style="display: none;">User Id:</label>
                    </div>
                </div>

                <div class="form-group">
                    <label class="control-label col-sm-2" for="user_name">User Name:</label>
                    <div class="col-sm-7">
                        <input type="text" class="form-control" id="user_name" placeholder="Enter your full name" name="name" required>
                    </div>
                </div>

                
                <div class="form-group">
                    <label class="control-label col-sm-2" for="user_email">Email:</label>
                    <div class="col-sm-7">
                        <input type="email" class="form-control" id="user_email" placeholder="Enter Your Email" name="email" required>
                    </div>
                </div>

                <div class="form-group">
                    <label class="control-label col-sm-2" for="personal_info">Date of Birth:</label>
                    <div class="col-sm-7">
                        <input type="date" class="form-control" id="user_birthdate"  name="birthdate" required>
                    </div>
                </div>

                <div class="form-group">
                    <label class="control-label col-sm-2" for="personal_info">Password:</label>
                    <div class="col-sm-7">
                        <input type="password" class="form-control" id="user_password" placeholder="Enter password" name="pswrd" required>
                    </div>
                </div>


                <div class="form-group">
                    <div class="col-sm-7">
                        <input type="hidden" class="form-control" id="token" value="{{csrf_token()}}" name="remember_token" required>
                    </div>
                </div>

                <div class="form-group">
                    <div class="col-sm-2" style="margin-left:492px">
                        <input type="submit" class="form-control" id="submit_button" value="Submit" name="btn">
                    </div>
                </div>

                
                
            </form>

            @endif
        </div>                               
        </div>

    </body>

</html>