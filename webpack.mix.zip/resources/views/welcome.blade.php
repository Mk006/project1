<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="utf-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width, initial-scale=1">
   
        <title>CDIP Jobs</title>
    <!--<link rel="icon" href="images/lg.png" sizes="32x32">-->

    <!-- Bootstrap -->


   
        <link href="https://fonts.googleapis.com/css?family=Open+Sans:300,400,600,700" rel="stylesheet">  
        <link href="{{asset('frontend/css/bootstrap.min.css')}}" rel="stylesheet">
        <link href="{{asset('frontend/css/bootstrap.min.css')}}" rel="stylesheet">
        <link href="{{asset('frontend/css/font-awesome.min.css')}}" rel="stylesheet">
        <link href="{{asset('frontend/css/style.css')}}"  rel="stylesheet">




    <style type="text/css">
        .dropbtn {
            cursor: pointer;
        }
        /* The container <div> - needed to position the dropdown content */
   

    </style>

   


</head>

<body>

    <nav class="navbar navbar-inverse mynav">
        <!--<nav class="navbar navbar-default mynav" data-spy="affix" data-offset-top="100">-->
        <div class="container">
            <!-- Brand and toggle get grouped for better mobile display -->
            <div class="navbar-header">
                <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#myid" aria-expanded="false">
        <span class="sr-only">Toggle navigation</span>
        <span class="icon-bar"></span>
        <span class="icon-bar"></span>
        <span class="icon-bar"></span>
      </button>

             
               

                <!-- <a class="navbar-brand" href="#">Brand</a>-->
            </div>

            <!-- Collect the nav links, forms, and other content for toggling -->
            <div class="collapse navbar-collapse" id="myid">
                <ul class="nav navbar-nav">
                    <li><?php echo '<a href="#index.php">Home<span class="sr-only">(current)</span></a>.'; ?></li>
                    

 


                 


@if(session('data'))
          
<li> <?php echo '<a href="createCV">CV</a>.'; ?></li>
     
@endif




        

                       
                    
                 
                    
                    
                    
                    



        </ul>
          
          
                <div class="logo hidden-xs">

                    <img src="{{URL::to('frontend/images/lg.png')}}" alt="" style="width:200; height:70px;">
                </div>

           
           
           
           @if(session('data'))

           <ul class="nav navbar-nav navbar-right">
                   
                    <li><a href="userregistration"> {{session('data')}} </a></li>
                <li> <?php echo '<a href="signout">Sign Out</a>.'; ?></li>

                </ul>
            
            @else
                <ul class="nav navbar-nav navbar-right">
                   
                    <li><?php echo '<a href="userregistration">Sign Up </a>.'; ?></li>
                <li> <?php echo '<a href="signin">Sign In</a>.'; ?></li>

                </ul>
                
      
            @endif

        
        </div>
        
        
        
         
        
     

        <!-- /.navbar-collapse -->
        </div>
        <!-- /.container-fluid -->
    </nav>


    <section>

    <div class="banner_slider">

        <div class="item" style="background:url(frontend/images/banner1.jpg)">
            <div class="container text-center">
                <div class="banner_inner">
                    <h2>CDIP Jobs</h2>
                    <P>know about our system</P>

                </div>
            </div>
        </div>

        <div class="item" style="background:url(frontend/images/banner1.jpg)">
            <div class="container text-center">
                <div class="banner_inner">
                    <h2>CDIP Jobs</h2>
                    <P>know about our system</P>

                </div>
            </div>
        </div>
        <div class="item" style="background:url(frontend/images/banner1.jpg)">
            <div class="container text-center">
                <div class="banner_inner">
                    <h2>CDIP Jobs</h2>
                    <P>know about our system</P>

                </div>
            </div>
        </div>
    </div>
</section>

<section class="end">
      
<div class="footer w3ls">
    <div class="container">
    
        <div class="footer-main">
            <div class="footer-top">
                <div class="col-md-4 ftr-grid fg1">
                    <h3><a href="index.html"><span>CDIP</span> Job Portal</a></h3>
                    <p>Founded: 2003.</p>
                    <p>Motto: Quest for Excellence.</p>

                </div>
                <div class="col-md-8 ftr-grid fg2 mid-gd">
                    <h3>Our Address</h3>
                    <div class="ftr-address">
                        <div class="local">
                            <i class="fa fa-map-marker" aria-hidden="true"></i>
                        </div>
                        <div class="ftr-text">
                            <p>House</p>
                        </div>
                        <div class="clearfix"> </div>
                    </div>
                    <div class="ftr-address">
                        <div class="local">
                            <i class="fa fa-phone" aria-hidden="true"></i>
                        </div>
                        <div class="ftr-text">
                            <p>+880 2-9125913</p>
                        </div>
                        <div class="clearfix"> </div>
                    </div>
                    <div class="ftr-address">
                    
                        
                        <div class="clearfix"> </div>
                    </div>
                </div>
                
               <div class="clearfix"> </div>
            </div>
            <div class="copyrights">
                <p>&copy; 2018 CDIP JOB PORTAL All Rights Reserved  </p>
            </div>
        </div>
    </div>
    
</div>
               

                        </section>





  
       
       
  
    
    
    
    

    <!-- jQuery (necessary for Bootstrap's JavaScript plugins) -->
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js"></script>
    <!-- Include all compiled plugins (below), or include individual files as needed -->
    
    <script src="{{asset('frontend/js/jquery.tubular.1.0.js')}}"></script>
      <script src="{{asset('frontend/js/jquery-1.12.4.min.js')}}"></script>
       <script src="{{asset('frontend/js/venobox.min.js')}}"></script>
     
    <script src="{{asset('frontend/js/bootstrap.min.js')}}"></script>
      <script src="{{asset('frontend/js/slick.min.js')}}"></script>
     <script src="{{asset('frontend/js/script.js')}}"></script>
  </body>
</html>