<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class extracurriculam extends Model
{
    //
}
